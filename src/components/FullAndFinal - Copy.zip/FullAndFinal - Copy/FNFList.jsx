import { Table } from 'antd'
import React from 'react'

const FNFList = () => {
  return (
    <div>
      <Table />
    </div>
  )
}

export default FNFList
