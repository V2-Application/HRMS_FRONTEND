import { CalculatorOutlined } from '@ant-design/icons'
import { Col, Form, Input, Row } from 'antd'
import { useState } from 'react'
import BonusCalculationModal from './BonusCalculationModal'
import ELCalculationModal from './ELCalculationModal'

const Additions = () => {
  const [isBonusModalOpen, setIsBonusModalOpen] = useState(false)
  const [isElModalOpen, setIsELModalOpen] = useState(false)

  const handleOpenBonusModal = () => {
    setIsBonusModalOpen(true)
  }

  const handleOpenELModal = () => {
    setIsELModalOpen(true)
  }

  return (
    <>
      <BonusCalculationModal open={isBonusModalOpen} setOpen={setIsBonusModalOpen} />
      <ELCalculationModal open={isElModalOpen} setOpen={setIsELModalOpen} />

      <div
        style={{
          paddingInline: '4rem',
        }}
      >
        <Form>
          <Form.Item label="Reason of Leaving">
            <Input />
          </Form.Item>

          <Row gutter={[16, 16]}>
            <Col span={12}>
              <Form.Item label="Full & Final Date">
                <Input />
              </Form.Item>
            </Col>

            <Col span={12}>
              <Form.Item label="Date of Leaving">
                <Input />
              </Form.Item>
            </Col>
          </Row>

          <Row gutter={[16, 16]}>
            <Col span={6}>
              <Form.Item label="Unpaid Salary Amount">
                <Input />
              </Form.Item>
            </Col>

            <Col span={6}>
              <Form.Item label="Rate">
                <Input />
              </Form.Item>
            </Col>

            <Col span={6}>
              <Form.Item label="Days">
                <Input />
              </Form.Item>
            </Col>

            <Col span={6}>
              <Form.Item label="Salary Month">
                <Input />
              </Form.Item>
            </Col>
          </Row>

          <Row gutter={[16, 16]}>
            <Col span={12}>
              <Form.Item label="Bonus">
                <Input suffix={<CalculatorOutlined onClick={handleOpenBonusModal} />} />
              </Form.Item>
            </Col>

            <Col span={6}>
              <Form.Item label="From">
                <Input />
              </Form.Item>
            </Col>

            <Col span={6}>
              <Form.Item label="To">
                <Input />
              </Form.Item>
            </Col>
          </Row>

          <Row>
            <Col span={24}>
              <Form.Item label="Gratuity">
                <Input />
              </Form.Item>
            </Col>
          </Row>

          <Row gutter={[16, 16]}>
            <Col span={12}>
              <Form.Item label="EL Days">
                <Input />
              </Form.Item>
            </Col>

            <Col span={12}>
              <Form.Item label="EL Amount">
                <Input suffix={<CalculatorOutlined onClick={handleOpenELModal} />} />
              </Form.Item>
            </Col>
          </Row>
        </Form>
      </div>
    </>
  )
}

export default Additions
