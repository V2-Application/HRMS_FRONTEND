import { Tabs } from 'antd'
import React from 'react'
import FNFList from './FNFList'
import NewFNF from './NewFNF'

const FNF = () => {
  const onChange = (key) => {
    console.log(key)
  }

  const items = [
    {
      key: '1',
      label: 'New',
      children: <NewFNF />,
    },
    {
      key: '2',
      label: 'List of FNFs',
      children: <FNFList />,
    },
  ]

  return (
    <div>
      <Tabs defaultActiveKey="1" items={items} onChange={onChange} />
    </div>
  )
}

export default FNF
