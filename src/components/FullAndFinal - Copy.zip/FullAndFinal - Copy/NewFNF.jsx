import { Tabs } from 'antd'
import React from 'react'
import Additions from './Additions'
import Deductions from './Deductions'
import EmployeeDetails from './EmployeeDetails'

const NewFNF = () => {
  const onChange = (key) => {
    console.log(key)
  }

  const items = [
    {
      key: '1',
      label: 'Additions',
      children: <Additions />,
    },
    {
      key: '2',
      label: 'Deductions',
      children: <Deductions />,
    },
  ]

  return (
    <div style={{ paddingInline: '0.8rem' }}>
      <EmployeeDetails />
      <Tabs defaultActiveKey="1" items={items} onChange={onChange} />
    </div>
  )
}

export default NewFNF
