import { UserOutlined } from '@ant-design/icons'
import { Button, Card, Select, Space } from 'antd'
import React from 'react'

const EmployeeDetails = () => {
  return (
    <div>
      <Card title={titleData()} variant="borderless">
        {cardData()}
      </Card>
    </div>
  )
}

export default EmployeeDetails

const titleData = () => {
  return (
    <Space>
      <Select placeholder="Select employee" style={{ width: '20rem' }}>
        <Option value="emp1">Employee 1</Option>
        <Option value="emp2">Employee 2</Option>
        <Option value="emp3">Employee 3</Option>
      </Select>

      <Button type="primary">Add</Button>
    </Space>
  )
}

const cardData = () => {
  const styles = {
    rowDisplay: {
      display: 'grid',
      gridTemplateColumns: 'repeat(3, 30%)',
      justifyContent: 'space-between',
    },
  }

  return (
    <div style={{ display: 'flex', gap: '2rem', width: '100%' }}>
      <UserOutlined style={{ fontSize: '3.5rem' }} />

      <div style={{ display: 'grid', gap: '1rem', flex: 1 }}>
        {/* row 1 */}
        <div style={styles.rowDisplay}>
          <span>
            <b>Name:</b> Employee Name
          </span>

          <span>
            <b>Department:</b> Department Name
          </span>

          <span>
            <b>Date of Joining:</b> 12/12/2024
          </span>
        </div>

        {/* row 2 */}
        <div style={styles.rowDisplay}>
          <span>
            <b>Code:</b> Employee Code
          </span>

          <span>
            <b>Designation:</b> Designation Name
          </span>

          <span>
            <b>Date of Leaving:</b> 12/12/2024
          </span>
        </div>
      </div>
    </div>
  )
}
