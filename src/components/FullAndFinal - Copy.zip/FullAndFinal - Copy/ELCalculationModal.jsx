import { Col, Form, Input, Modal, Row } from 'antd'
import React from 'react'

const ELCalculationModal = ({ open, setOpen }) => {
  return (
    <Modal
      title="Earned Leave Calculation"
      centered
      open={open}
      onOk={() => setOpen(false)}
      onCancel={() => setOpen(false)}
      width={1000}
    >
      <Form>
        <Row gutter={[16, 16]}>
          <Col span={4}>Bonus Period:</Col>

          <Col span={10}>
            <Form.Item label="From">
              <Input />
            </Form.Item>
          </Col>

          <Col span={10}>
            <Form.Item label="To">
              <Input />
            </Form.Item>
          </Col>
        </Row>

        <Row>
          <Col span={24}>
            <Form.Item label="Bonus Rate">
              <Input suffix={'%'} />
            </Form.Item>
          </Col>
        </Row>

        <Row>
          <Col span={24}>
            <Form.Item label="Min. worked days in period">
              <Input suffix={'%'} />
            </Form.Item>
          </Col>
        </Row>
      </Form>
    </Modal>
  )
}

export default ELCalculationModal
